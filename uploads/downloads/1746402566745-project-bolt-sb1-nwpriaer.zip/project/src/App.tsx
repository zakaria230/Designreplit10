import React, { useState, useEffect } from 'react';
import { GameProvider, useGame } from './contexts/GameContext';
import FarmGrid from './components/FarmGrid';
import Toolbar from './components/Toolbar';
import Inventory from './components/Inventory';
import WalletConnect from './components/WalletConnect';
import MarketBoard from './components/MarketBoard';
import WeatherIndicator from './components/WeatherIndicator';
import LoadingScreen from './components/LoadingScreen';
import HomePage from './components/HomePage';
import { Sprout } from 'lucide-react';

const GameContent = () => {
  const { state } = useGame();
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-amber-100 relative overflow-hidden">
      {/* Decorative Trees */}
      <div className="absolute top-0 left-0 w-32 h-48 transform -translate-x-8">
        <div className="absolute bottom-0 left-1/2 w-4 h-32 bg-amber-800 transform -translate-x-1/2"></div>
        <div className="absolute bottom-16 left-1/2 w-24 h-24 bg-green-700 rounded-full transform -translate-x-1/2 animate-sway"></div>
      </div>
      <div className="absolute top-0 right-0 w-32 h-56 transform translate-x-8">
        <div className="absolute bottom-0 left-1/2 w-4 h-40 bg-amber-800 transform -translate-x-1/2"></div>
        <div className="absolute bottom-24 left-1/2 w-28 h-28 bg-green-800 rounded-full transform -translate-x-1/2 animate-sway-delayed"></div>
      </div>
      
      {/* Background Hills */}
      <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-t from-amber-200 to-transparent -z-10"></div>
      <div className="absolute bottom-0 left-0 w-1/2 h-48 bg-gradient-to-t from-amber-300 to-transparent rounded-full transform scale-150 translate-x-1/4 -z-20"></div>
      <div className="absolute bottom-0 right-0 w-1/2 h-40 bg-gradient-to-t from-amber-300 to-transparent rounded-full transform scale-150 -translate-x-1/4 -z-20"></div>

      <header className="bg-gradient-to-r from-amber-600 to-amber-700 text-white p-4 shadow-lg relative z-10">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Sprout size={28} className="animate-bounce" />
            <h1 className="text-xl font-bold">CryptoTaters</h1>
          </div>
          <WalletConnect />
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-6 relative z-10">
        <WeatherIndicator />
        <Toolbar />
        <FarmGrid />
        
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <Inventory />
          <MarketBoard />
        </div>
        
        <div className="mt-8 text-center text-sm text-gray-600">
          <p>Remember: Water your crops daily for the best yields!</p>
          <p className="mt-2">© 2025 CryptoTaters - All Rights Reserved</p>
        </div>
      </main>
    </div>
  );
};

const GameContainer = () => {
  const { state } = useGame();
  return state.isPlaying ? <GameContent /> : <HomePage />;
};

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);
    
    return () => clearTimeout(timer);
  }, []);

  return (
    <GameProvider>
      <div>
        <LoadingScreen isVisible={isLoading} />
        {!isLoading && (
          <div className="animate-fade-in">
            <GameContainer />
          </div>
        )}
      </div>
    </GameProvider>
  );
}

export default App;