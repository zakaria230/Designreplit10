// Game Types
export type CropStage = 'empty' | 'seed' | 'sprout' | 'mature';
export type SoilState = 'dry' | 'watered';
export type ToolType = 'seed' | 'water' | 'harvest';
export type PotatoRarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';

export interface Crop {
  id: string;
  stage: CropStage;
  soil: SoilState;
  plantedAt: number | null;
  wateringTime: number | null;
  rarity: PotatoRarity | null;
  readyAt: number | null;
}

export interface Potato {
  id: string;
  rarity: PotatoRarity;
  value: number;
  harvestedAt: number;
}

export interface InventoryItem {
  type: 'seed' | 'potato';
  rarity: PotatoRarity;
  count: number;
}

export interface GameState {
  farmGrid: Crop[];
  inventory: InventoryItem[];
  taterTokens: number;
  selectedTool: ToolType | null;
  isWalletConnected: boolean;
  marketPrices: {
    [key in PotatoRarity]: number;
  };
  weather: 'sunny' | 'rainy';
  isPlaying: boolean;
}