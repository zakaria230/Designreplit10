import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { GameState, Crop, ToolType, PotatoRarity, Potato } from '../types';

const createEmptyGrid = (): Crop[] => {
  return Array(36).fill(null).map(() => ({
    id: uuidv4(),
    stage: 'empty',
    soil: 'dry',
    plantedAt: null,
    wateringTime: null,
    rarity: null,
    readyAt: null
  }));
};

const initialMarketPrices = {
  common: 5,
  uncommon: 12,
  rare: 25,
  epic: 75,
  legendary: 250
};

const initialState: GameState = {
  farmGrid: createEmptyGrid(),
  inventory: [
    { type: 'seed', rarity: 'common', count: 10 },
    { type: 'seed', rarity: 'uncommon', count: 5 },
    { type: 'seed', rarity: 'rare', count: 2 }
  ],
  taterTokens: 100,
  selectedTool: null,
  isWalletConnected: false,
  marketPrices: initialMarketPrices,
  weather: 'sunny',
  isPlaying: false
};

type GameAction =
  | { type: 'SELECT_TOOL'; payload: ToolType | null }
  | { type: 'PLANT_SEED'; payload: { plotIndex: number, rarity: PotatoRarity } }
  | { type: 'WATER_CROP'; payload: number }
  | { type: 'HARVEST_CROP'; payload: number }
  | { type: 'UPDATE_CROPS' }
  | { type: 'CONNECT_WALLET'; payload: boolean }
  | { type: 'UPDATE_WEATHER'; payload: 'sunny' | 'rainy' }
  | { type: 'SELL_POTATO'; payload: { potatoId: string, price: number } }
  | { type: 'START_GAME' };

const gameReducer = (state: GameState, action: GameAction): GameState => {
  switch (action.type) {
    case 'SELECT_TOOL':
      return { ...state, selectedTool: action.payload };

    case 'PLANT_SEED': {
      const { plotIndex, rarity } = action.payload;
      const newGrid = [...state.farmGrid];
      
      if (newGrid[plotIndex].stage !== 'empty') return state;
      
      const seedIndex = state.inventory.findIndex(
        item => item.type === 'seed' && item.rarity === rarity
      );
      
      if (seedIndex === -1 || state.inventory[seedIndex].count <= 0) return state;
      
      const newInventory = [...state.inventory];
      newInventory[seedIndex] = {
        ...newInventory[seedIndex],
        count: newInventory[seedIndex].count - 1
      };
      
      if (newInventory[seedIndex].count === 0) {
        newInventory.splice(seedIndex, 1);
      }
      
      newGrid[plotIndex] = {
        ...newGrid[plotIndex],
        stage: 'seed',
        soil: 'dry',
        plantedAt: Date.now(),
        rarity: rarity
      };
      
      return {
        ...state,
        farmGrid: newGrid,
        inventory: newInventory
      };
    }

    case 'WATER_CROP': {
      const plotIndex = action.payload;
      const newGrid = [...state.farmGrid];
      const crop = newGrid[plotIndex];
      
      if (crop.stage === 'empty' || crop.soil === 'watered') return state;
      
      newGrid[plotIndex] = {
        ...crop,
        soil: 'watered',
        wateringTime: Date.now(),
        readyAt: Date.now() + (
          crop.stage === 'seed' 
            ? calculateGrowthTime(crop.rarity || 'common', state.weather) 
            : 0
        )
      };
      
      return {
        ...state,
        farmGrid: newGrid
      };
    }

    case 'HARVEST_CROP': {
      const plotIndex = action.payload;
      const crop = state.farmGrid[plotIndex];
      
      if (crop.stage !== 'mature') return state;
      
      const newGrid = [...state.farmGrid];
      
      newGrid[plotIndex] = {
        ...newGrid[plotIndex],
        stage: 'empty',
        soil: 'dry',
        plantedAt: null,
        wateringTime: null,
        rarity: null,
        readyAt: null
      };
      
      const potatoRarity = crop.rarity || 'common';
      const newInventory = [...state.inventory];
      
      const existingIndex = newInventory.findIndex(
        item => item.type === 'potato' && item.rarity === potatoRarity
      );
      
      if (existingIndex >= 0) {
        newInventory[existingIndex] = {
          ...newInventory[existingIndex],
          count: newInventory[existingIndex].count + 1
        };
      } else {
        newInventory.push({
          type: 'potato',
          rarity: potatoRarity,
          count: 1
        });
      }
      
      return {
        ...state,
        farmGrid: newGrid,
        inventory: newInventory
      };
    }

    case 'UPDATE_CROPS': {
      const now = Date.now();
      const newGrid = [...state.farmGrid].map(crop => {
        if (crop.stage === 'empty') return crop;
        
        if (crop.stage === 'seed' && crop.soil === 'watered' && crop.readyAt && now > crop.readyAt) {
          return {
            ...crop,
            stage: 'sprout',
            readyAt: now + calculateGrowthTime(crop.rarity || 'common', state.weather)
          };
        }
        
        if (crop.stage === 'sprout' && crop.soil === 'watered' && crop.readyAt && now > crop.readyAt) {
          return {
            ...crop,
            stage: 'mature'
          };
        }
        
        return crop;
      });
      
      return {
        ...state,
        farmGrid: newGrid
      };
    }

    case 'CONNECT_WALLET':
      return {
        ...state,
        isWalletConnected: action.payload
      };

    case 'UPDATE_WEATHER':
      return {
        ...state,
        weather: action.payload
      };

    case 'SELL_POTATO': {
      const { potatoId, price } = action.payload;
      const potatoIndex = state.inventory.findIndex(
        item => item.type === 'potato'
      );
      
      if (potatoIndex === -1 || state.inventory[potatoIndex].count <= 0) return state;
      
      const newInventory = [...state.inventory];
      newInventory[potatoIndex] = {
        ...newInventory[potatoIndex],
        count: newInventory[potatoIndex].count - 1
      };
      
      if (newInventory[potatoIndex].count === 0) {
        newInventory.splice(potatoIndex, 1);
      }
      
      return {
        ...state,
        taterTokens: state.taterTokens + price,
        inventory: newInventory
      };
    }

    case 'START_GAME':
      return {
        ...state,
        isPlaying: true
      };

    default:
      return state;
  }
};

const calculateGrowthTime = (rarity: PotatoRarity, weather: 'sunny' | 'rainy'): number => {
  const baseTime = {
    common: 10 * 1000,
    uncommon: 15 * 1000,
    rare: 20 * 1000,
    epic: 30 * 1000,
    legendary: 45 * 1000
  };
  
  const weatherMultiplier = weather === 'rainy' ? 0.7 : 1;
  
  return baseTime[rarity] * weatherMultiplier;
};

type GameContextType = {
  state: GameState;
  selectTool: (tool: ToolType | null) => void;
  plantSeed: (plotIndex: number, rarity: PotatoRarity) => void;
  waterCrop: (plotIndex: number) => void;
  harvestCrop: (plotIndex: number) => void;
  connectWallet: (connected: boolean) => void;
  sellPotato: (potatoId: string) => void;
  startGame: () => void;
};

const GameContext = createContext<GameContextType | undefined>(undefined);

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  useEffect(() => {
    const intervalId = setInterval(() => {
      dispatch({ type: 'UPDATE_CROPS' });
    }, 10000);
    
    return () => clearInterval(intervalId);
  }, []);

  useEffect(() => {
    const changeWeather = () => {
      const isRainy = Math.random() > 0.7;
      dispatch({ type: 'UPDATE_WEATHER', payload: isRainy ? 'rainy' : 'sunny' });
    };
    
    const intervalId = setInterval(changeWeather, 3 * 60 * 1000);
    
    return () => clearInterval(intervalId);
  }, []);

  const selectTool = (tool: ToolType | null) => {
    dispatch({ type: 'SELECT_TOOL', payload: tool });
  };

  const plantSeed = (plotIndex: number, rarity: PotatoRarity) => {
    if (state.selectedTool === 'seed') {
      dispatch({ type: 'PLANT_SEED', payload: { plotIndex, rarity } });
    }
  };

  const waterCrop = (plotIndex: number) => {
    if (state.selectedTool === 'water') {
      dispatch({ type: 'WATER_CROP', payload: plotIndex });
    }
  };

  const harvestCrop = (plotIndex: number) => {
    if (state.selectedTool === 'harvest') {
      dispatch({ type: 'HARVEST_CROP', payload: plotIndex });
    }
  };

  const connectWallet = (connected: boolean) => {
    dispatch({ type: 'CONNECT_WALLET', payload: connected });
  };

  const sellPotato = (potatoId: string) => {
    const potato = state.inventory.find(item => 
      item.type === 'potato' && item.id === potatoId
    );
    
    if (potato) {
      const price = state.marketPrices[potato.rarity];
      dispatch({ type: 'SELL_POTATO', payload: { potatoId, price } });
    }
  };

  const startGame = () => {
    dispatch({ type: 'START_GAME' });
  };

  return (
    <GameContext.Provider value={{
      state,
      selectTool,
      plantSeed,
      waterCrop,
      harvestCrop,
      connectWallet,
      sellPotato,
      startGame
    }}>
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};