import React from 'react';

interface LoadingScreenProps {
  isVisible: boolean;
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({ isVisible }) => {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-gradient-to-b from-amber-800 to-amber-950 flex flex-col items-center justify-center z-50">
      <div className="mb-8 text-5xl font-bold text-white tracking-wider">CryptoTaters</div>
      
      <div className="w-48 h-48 mb-8 relative">
        {/* Animated farm scene */}
        <div className="absolute inset-0">
          {/* Ground */}
          <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-amber-900 to-amber-800 rounded-lg"></div>
          
          {/* Plants */}
          <div className="absolute bottom-24 left-4 flex items-end space-x-4">
            <div className="w-8 h-16 bg-gradient-to-t from-green-700 to-green-500 rounded-t-full animate-pulse"></div>
            <div className="w-8 h-20 bg-gradient-to-t from-green-800 to-green-600 rounded-t-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
            <div className="w-8 h-24 bg-gradient-to-t from-green-700 to-green-500 rounded-t-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
          </div>
          
          {/* Sun */}
          <div className="absolute top-4 right-4">
            <div className="w-12 h-12 bg-gradient-to-br from-yellow-300 to-yellow-500 rounded-full animate-pulse shadow-lg"></div>
            <div className="absolute inset-0 bg-gradient-to-br from-yellow-300 to-yellow-500 rounded-full blur-md opacity-50"></div>
          </div>
        </div>
      </div>
      
      <div className="text-white text-xl animate-pulse">
        Connecting to Farm...
      </div>
    </div>
  );
};

export default LoadingScreen;