import React from 'react';
import { useGame } from '../contexts/GameContext';
import { Sprout } from 'lucide-react';

const HomePage: React.FC = () => {
  const { startGame } = useGame();

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-amber-100 flex flex-col items-center justify-center p-4">
      <div className="text-center max-w-2xl animate-fade-in">
        <div className="flex items-center justify-center mb-6">
          <Sprout className="w-16 h-16 text-amber-600 animate-bounce" />
        </div>
        
        <h1 className="text-6xl font-bold text-amber-900 mb-4 animate-slide-up">
          CryptoTaters
        </h1>
        
        <p className="text-xl text-amber-700 mb-8 animate-fade-in-delay">
          Grow, harvest, and trade magical potatoes in this exciting farming adventure!
        </p>
        
        <div className="space-y-6 animate-fade-in-delay-2">
          <button
            onClick={startGame}
            className="px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white rounded-full text-xl font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
          >
            Start Farming
          </button>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-12">
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-lg font-semibold text-amber-800 mb-2">Plant & Grow</h3>
              <p className="text-amber-600">Plant magical seeds and watch them grow into valuable potatoes</p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-lg font-semibold text-amber-800 mb-2">Harvest & Collect</h3>
              <p className="text-amber-600">Harvest rare and legendary potatoes to build your collection</p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-shadow">
              <h3 className="text-lg font-semibold text-amber-800 mb-2">Trade & Earn</h3>
              <p className="text-amber-600">Trade your potatoes for Tater Tokens in the dynamic market</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;