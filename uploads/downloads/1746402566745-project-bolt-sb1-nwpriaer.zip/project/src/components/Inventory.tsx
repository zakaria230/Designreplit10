import React, { useState } from 'react';
import { useGame } from '../contexts/GameContext';
import { InventoryItem, PotatoRarity } from '../types';

const Inventory: React.FC = () => {
  const { state, sellPotato } = useGame();
  const { inventory, marketPrices } = state;
  const [activeTab, setActiveTab] = useState<'seeds' | 'potatoes'>('seeds');

  const seeds = inventory.filter(item => item.type === 'seed');
  const potatoes = inventory.filter(item => item.type === 'potato');

  const getRarityColor = (rarity: PotatoRarity) => {
    switch (rarity) {
      case 'common':
        return 'bg-amber-500';
      case 'uncommon':
        return 'bg-green-500';
      case 'rare':
        return 'bg-blue-500';
      case 'epic':
        return 'bg-purple-500';
      case 'legendary':
        return 'bg-yellow-400';
      default:
        return 'bg-gray-300';
    }
  };

  const handleSellPotato = (item: InventoryItem) => {
    // Generate a temporary ID for this transaction
    const tempId = `${item.type}-${item.rarity}-${Date.now()}`;
    sellPotato(tempId);
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 mt-4">
      <div className="flex border-b mb-4">
        <button
          className={`px-4 py-2 ${
            activeTab === 'seeds' ? 'border-b-2 border-amber-500 font-medium' : ''
          }`}
          onClick={() => setActiveTab('seeds')}
        >
          Seeds
        </button>
        <button
          className={`px-4 py-2 ${
            activeTab === 'potatoes' ? 'border-b-2 border-amber-500 font-medium' : ''
          }`}
          onClick={() => setActiveTab('potatoes')}
        >
          Potatoes
        </button>
      </div>

      <div className="space-y-2">
        {activeTab === 'seeds' ? (
          <>
            <h3 className="text-lg font-medium">Your Seeds</h3>
            {seeds.length === 0 ? (
              <p className="text-gray-500">No seeds in inventory</p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {seeds.map((item, index) => (
                  <div key={index} className="border rounded-md p-2 flex items-center space-x-2">
                    <div className={`w-4 h-4 rounded-full ${getRarityColor(item.rarity)}`}></div>
                    <div>
                      <div className="font-medium capitalize">{item.rarity}</div>
                      <div className="text-sm text-gray-500">x{item.count}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        ) : (
          <>
            <h3 className="text-lg font-medium">Your Potatoes</h3>
            {potatoes.length === 0 ? (
              <p className="text-gray-500">No potatoes harvested yet</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {potatoes.map((item, index) => (
                  <div key={index} className="border rounded-md p-2 flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <div className={`w-6 h-6 rounded-full ${getRarityColor(item.rarity)}`}></div>
                      <div>
                        <div className="font-medium capitalize">{item.rarity}</div>
                        <div className="text-sm text-gray-500">x{item.count}</div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleSellPotato(item)}
                      className="px-2 py-1 bg-green-500 text-white text-sm rounded hover:bg-green-600"
                    >
                      Sell ({marketPrices[item.rarity]} TT)
                    </button>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Inventory;