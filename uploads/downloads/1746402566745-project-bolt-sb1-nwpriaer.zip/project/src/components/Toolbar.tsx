import React from 'react';
import { useGame } from '../contexts/GameContext';
import { ToolType } from '../types';
import { Shovel, Droplets, Scissors } from 'lucide-react';

const Toolbar: React.FC = () => {
  const { state, selectTool } = useGame();
  const { selectedTool } = state;

  const tools: { id: ToolType; icon: React.ReactNode; label: string }[] = [
    { 
      id: 'seed', 
      icon: <Shovel size={24} />, 
      label: 'Plant' 
    },
    { 
      id: 'water', 
      icon: <Droplets size={24} />, 
      label: 'Water' 
    },
    { 
      id: 'harvest', 
      icon: <Scissors size={24} />, 
      label: 'Harvest' 
    }
  ];

  const handleToolClick = (toolId: ToolType) => {
    // If the same tool is clicked again, deselect it
    if (selectedTool === toolId) {
      selectTool(null);
    } else {
      selectTool(toolId);
    }
  };

  return (
    <div className="flex justify-center space-x-2 my-4">
      {tools.map((tool) => (
        <button
          key={tool.id}
          onClick={() => handleToolClick(tool.id)}
          className={`flex flex-col items-center p-2 rounded-lg ${
            selectedTool === tool.id
              ? 'bg-amber-500 text-white'
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          } transition-colors duration-200`}
        >
          {tool.icon}
          <span className="text-xs mt-1">{tool.label}</span>
        </button>
      ))}
    </div>
  );
};

export default Toolbar;