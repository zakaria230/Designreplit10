import React from 'react';
import { useGame } from '../contexts/GameContext';
import { PotatoRarity } from '../types';
import { TrendingUp, TrendingDown } from 'lucide-react';

const MarketBoard: React.FC = () => {
  const { state } = useGame();
  const { marketPrices } = state;

  const trends: Record<PotatoRarity, { isUp: boolean; percent: number }> = {
    common: { isUp: Math.random() > 0.5, percent: Math.floor(Math.random() * 5) + 1 },
    uncommon: { isUp: Math.random() > 0.5, percent: Math.floor(Math.random() * 8) + 1 },
    rare: { isUp: Math.random() > 0.5, percent: Math.floor(Math.random() * 12) + 1 },
    epic: { isUp: Math.random() > 0.5, percent: Math.floor(Math.random() * 15) + 1 },
    legendary: { isUp: Math.random() > 0.5, percent: Math.floor(Math.random() * 20) + 1 }
  };

  const getRarityStyle = (rarity: PotatoRarity) => {
    switch (rarity) {
      case 'common':
        return 'bg-gradient-to-r from-amber-400 to-amber-600';
      case 'uncommon':
        return 'bg-gradient-to-r from-green-400 to-green-600';
      case 'rare':
        return 'bg-gradient-to-r from-blue-400 to-blue-600';
      case 'epic':
        return 'bg-gradient-to-r from-purple-400 to-purple-600';
      case 'legendary':
        return 'bg-gradient-to-r from-yellow-300 to-yellow-500';
      default:
        return 'bg-gradient-to-r from-amber-400 to-amber-600';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mt-4 border border-amber-100">
      <h2 className="text-2xl font-bold mb-4 text-amber-900">Tater Market</h2>
      <div className="space-y-3">
        {Object.entries(marketPrices).map(([rarity, price]) => (
          <div key={rarity} className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-amber-50 to-transparent hover:from-amber-100 transition-colors">
            <div className="flex items-center space-x-3">
              <div className={`w-6 h-6 rounded-full ${getRarityStyle(rarity as PotatoRarity)} shadow-md`}></div>
              <span className="capitalize font-medium">{rarity}</span>
            </div>
            <div className="flex items-center space-x-3">
              <span className="font-bold text-lg">{price} TT</span>
              <div className={`flex items-center ${
                trends[rarity as PotatoRarity].isUp ? 'text-green-500' : 'text-red-500'
              }`}>
                {trends[rarity as PotatoRarity].isUp ? (
                  <TrendingUp size={20} />
                ) : (
                  <TrendingDown size={20} />
                )}
                <span className="text-sm ml-1">
                  {trends[rarity as PotatoRarity].percent}%
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-4 text-sm text-amber-700 bg-amber-50 p-3 rounded-lg">
        Market prices update every 24 hours
      </div>
    </div>
  );
};

export default MarketBoard;