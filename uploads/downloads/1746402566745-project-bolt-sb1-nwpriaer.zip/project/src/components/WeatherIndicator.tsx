import React from 'react';
import { useGame } from '../contexts/GameContext';
import { CloudRain, Sun } from 'lucide-react';

const WeatherIndicator: React.FC = () => {
  const { state } = useGame();
  const { weather } = state;

  return (
    <div className="flex items-center justify-center py-2">
      <div className={`flex items-center px-3 py-1 rounded-full ${
        weather === 'rainy' 
          ? 'bg-blue-100 text-blue-700' 
          : 'bg-yellow-100 text-yellow-700'
      }`}>
        {weather === 'rainy' ? (
          <>
            <CloudRain size={18} className="mr-1" />
            <span>Rainy (30% faster growth)</span>
          </>
        ) : (
          <>
            <Sun size={18} className="mr-1" />
            <span>Sunny</span>
          </>
        )}
      </div>
    </div>
  );
};

export default WeatherIndicator;