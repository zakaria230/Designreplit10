import React from 'react';
import { useGame } from '../contexts/GameContext';
import { Wallet } from 'lucide-react';

const WalletConnect: React.FC = () => {
  const { state, connectWallet } = useGame();
  const { isWalletConnected, taterTokens } = state;

  const handleConnectClick = () => {
    // Simulate wallet connection
    // In a real app, this would integrate with MetaMask or WalletConnect
    connectWallet(!isWalletConnected);
  };

  return (
    <div className="mb-4 flex flex-col sm:flex-row items-center justify-between gap-2">
      <div className="flex items-center">
        {isWalletConnected && (
          <div className="mr-4 bg-amber-100 text-amber-800 px-3 py-1 rounded-full flex items-center">
            <span className="font-semibold">{taterTokens}</span>
            <span className="ml-1">TT</span>
          </div>
        )}
      </div>
      <button
        onClick={handleConnectClick}
        className={`flex items-center px-4 py-2 rounded-full font-medium ${
          isWalletConnected
            ? 'bg-green-100 text-green-700 hover:bg-green-200'
            : 'bg-amber-500 text-white hover:bg-amber-600'
        } transition-colors duration-200`}
      >
        <Wallet size={18} className="mr-2" />
        {isWalletConnected ? 'Wallet Connected' : 'Connect Wallet'}
      </button>
    </div>
  );
};

export default WalletConnect;