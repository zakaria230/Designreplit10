import React from 'react';
import Plot from './Plot';
import { useGame } from '../contexts/GameContext';

const FarmGrid: React.FC = () => {
  const { state, plantSeed, waterCrop, harvestCrop } = useGame();
  const { farmGrid, selectedTool } = state;

  const handlePlotClick = (index: number) => {
    const plot = farmGrid[index];
    
    switch (selectedTool) {
      case 'seed':
        const seed = state.inventory.find(item => item.type === 'seed');
        if (seed) {
          plantSeed(index, seed.rarity);
        }
        break;
      case 'water':
        waterCrop(index);
        break;
      case 'harvest':
        harvestCrop(index);
        break;
      default:
        break;
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-8">
      <div className="farm-grid grid grid-cols-6 gap-4 p-4 bg-gradient-to-b from-amber-800 to-amber-900 rounded-2xl shadow-3d">
        {farmGrid.map((crop, index) => (
          <Plot 
            key={crop.id} 
            crop={crop} 
            onClick={() => handlePlotClick(index)} 
          />
        ))}
      </div>
    </div>
  );
};

export default FarmGrid;