import React from 'react';
import { Crop } from '../types';
import { useGame } from '../contexts/GameContext';

interface PlotProps {
  crop: Crop;
  onClick: () => void;
}

const Plot: React.FC<PlotProps> = ({ crop, onClick }) => {
  const { state } = useGame();
  const { selectedTool } = state;

  const isValidAction = () => {
    if (!selectedTool) return false;
    
    switch (selectedTool) {
      case 'seed':
        return crop.stage === 'empty';
      case 'water':
        return (crop.stage === 'seed' || crop.stage === 'sprout') && crop.soil === 'dry';
      case 'harvest':
        return crop.stage === 'mature';
      default:
        return false;
    }
  };

  const getTimeRemaining = () => {
    if (!crop.readyAt) return null;
    
    const timeLeft = crop.readyAt - Date.now();
    if (timeLeft <= 0) return "Ready!";
    
    const minutes = Math.floor(timeLeft / (60 * 1000));
    const seconds = Math.floor((timeLeft % (60 * 1000)) / 1000);
    
    return `${minutes}m ${seconds}s`;
  };

  const getPlotClasses = () => {
    let classes = "plot-3d w-full aspect-square rounded-lg relative overflow-hidden transition-all duration-300 ";
    
    classes += crop.soil === 'watered' 
      ? "bg-gradient-to-b from-amber-700 to-amber-800" 
      : "bg-gradient-to-b from-amber-800 to-amber-900";
    
    if (isValidAction()) {
      classes += " cursor-pointer hover:shadow-xl";
    } else {
      classes += " cursor-default";
    }
    
    return classes;
  };

  const getCropClasses = () => {
    if (crop.stage === 'empty') return "";
    
    let classes = "crop-3d absolute inset-0 flex items-center justify-center transition-all duration-300 ";
    
    if (crop.stage === 'seed') {
      classes += "scale-75";
    } else if (crop.stage === 'sprout') {
      classes += "scale-90";
    } else if (crop.stage === 'mature') {
      classes += "scale-100 animate-float";
    }
    
    return classes;
  };

  const renderCrop = () => {
    switch (crop.stage) {
      case 'empty':
        return null;
      case 'seed':
        return (
          <div className="relative transform-gpu">
            <div className="w-3 h-3 bg-gradient-to-br from-amber-500 to-amber-700 rounded-full shadow-lg"></div>
            <div className="absolute -top-1 left-1/2 w-1 h-2 bg-gradient-to-b from-amber-600 to-amber-800 -translate-x-1/2"></div>
          </div>
        );
      case 'sprout':
        return (
          <div className="relative transform-gpu">
            <div className="w-6 h-8 bg-gradient-to-b from-green-500 to-green-700 rounded-t-full shadow-lg"></div>
            <div className="absolute bottom-0 left-1/2 w-1 h-4 bg-gradient-to-b from-green-600 to-green-800 -translate-x-1/2"></div>
          </div>
        );
      case 'mature':
        return (
          <div className={`relative transform-gpu ${getRarityGlow()}`}>
            <div className={`w-12 h-12 ${getRarityColor()} rounded-full shadow-lg transform transition-transform hover:scale-110`}></div>
            <div className="absolute -top-4 left-1/2 w-2 h-6 bg-gradient-to-b from-green-600 to-green-800 -translate-x-1/2"></div>
            <div className="absolute -top-2 left-1/2 w-6 h-4 bg-gradient-to-b from-green-500 to-green-700 -translate-x-1/2 rounded-full"></div>
          </div>
        );
    }
  };

  const getRarityColor = () => {
    switch (crop.rarity) {
      case 'common':
        return 'bg-gradient-to-br from-amber-400 to-amber-600';
      case 'uncommon':
        return 'bg-gradient-to-br from-green-400 to-green-600';
      case 'rare':
        return 'bg-gradient-to-br from-blue-400 to-blue-600';
      case 'epic':
        return 'bg-gradient-to-br from-purple-400 to-purple-600';
      case 'legendary':
        return 'bg-gradient-to-br from-yellow-300 to-yellow-500 animate-rotate3d';
      default:
        return 'bg-gradient-to-br from-amber-400 to-amber-600';
    }
  };

  const getRarityGlow = () => {
    switch (crop.rarity) {
      case 'epic':
        return 'filter drop-shadow-[0_0_8px_rgba(147,51,234,0.5)]';
      case 'legendary':
        return 'filter drop-shadow-[0_0_12px_rgba(234,179,8,0.6)]';
      default:
        return '';
    }
  };

  return (
    <div 
      className={getPlotClasses()}
      onClick={onClick}
      title={crop.stage !== 'empty' ? `${crop.rarity} potato - ${getTimeRemaining()}` : 'Empty plot'}
    >
      <div className={getCropClasses()}>
        {renderCrop()}
      </div>
      
      {crop.stage === 'mature' && (
        <div className="absolute top-1 right-1 bg-green-500 text-white text-xs px-2 py-1 rounded-full shadow-md transform-gpu translate-z-10">
          ✓
        </div>
      )}
      
      {crop.soil === 'watered' && crop.stage !== 'empty' && crop.stage !== 'mature' && (
        <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-gradient-to-r from-blue-400 to-blue-500 bg-opacity-70 rounded-b-lg"></div>
      )}
    </div>
  );
};

export default Plot;