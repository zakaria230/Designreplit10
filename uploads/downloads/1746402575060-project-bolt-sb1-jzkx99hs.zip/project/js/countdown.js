// Countdown timer functionality

/**
 * Sets up a countdown timer for tournaments
 * @param {string} elementId - The ID of the element to update
 * @param {string} targetDate - The target date in ISO format
 */
export function setupCountdown(elementId, targetDate) {
  const countdownElement = document.getElementById(elementId);
  if (!countdownElement) return;
  
  const targetTime = new Date(targetDate).getTime();
  
  // Elements for days, hours, minutes, seconds
  const daysElement = countdownElement.querySelector('.days');
  const hoursElement = countdownElement.querySelector('.hours');
  const minutesElement = countdownElement.querySelector('.minutes');
  const secondsElement = countdownElement.querySelector('.seconds');
  
  // Update the countdown every second
  function updateCountdown() {
    const now = new Date().getTime();
    const distance = targetTime - now;
    
    // Calculate time units
    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    // Update the HTML
    if (daysElement) daysElement.textContent = formatTimeUnit(days);
    if (hoursElement) hoursElement.textContent = formatTimeUnit(hours);
    if (minutesElement) minutesElement.textContent = formatTimeUnit(minutes);
    if (secondsElement) secondsElement.textContent = formatTimeUnit(seconds);
    
    // Add pulse animation to changing units
    addPulseAnimation(secondsElement);
    
    if (seconds === 59) {
      addPulseAnimation(minutesElement);
    }
    
    if (seconds === 59 && minutes === 59) {
      addPulseAnimation(hoursElement);
    }
    
    if (seconds === 59 && minutes === 59 && hours === 23) {
      addPulseAnimation(daysElement);
    }
    
    // If the countdown is over
    if (distance < 0) {
      clearInterval(countdownInterval);
      if (daysElement) daysElement.textContent = '00';
      if (hoursElement) hoursElement.textContent = '00';
      if (minutesElement) minutesElement.textContent = '00';
      if (secondsElement) secondsElement.textContent = '00';
      
      const countdownTitle = countdownElement.previousElementSibling;
      if (countdownTitle) {
        countdownTitle.textContent = 'Tournament Live Now!';
        countdownTitle.style.color = 'var(--color-accent-red)';
        countdownTitle.classList.add('animate-pulse');
      }
    }
  }
  
  // Format time units to always be two digits
  function formatTimeUnit(unit) {
    return unit < 10 ? `0${unit}` : `${unit}`;
  }
  
  // Add pulse animation to changing elements
  function addPulseAnimation(element) {
    if (!element) return;
    
    element.classList.add('pulse-animation');
    setTimeout(() => {
      element.classList.remove('pulse-animation');
    }, 500);
  }
  
  // Initial call to set the values immediately
  updateCountdown();
  
  // Set interval to update every second
  const countdownInterval = setInterval(updateCountdown, 1000);
  
  // Cleanup function to clear interval if needed
  return () => clearInterval(countdownInterval);
}