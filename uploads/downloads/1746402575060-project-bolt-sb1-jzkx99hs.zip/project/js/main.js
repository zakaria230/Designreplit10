// Main JavaScript file for the gaming website

import '../styles/main.css';
import '../styles/animations.css';
import '../styles/responsive.css';
import { setupCountdown } from './countdown.js';
import { setupNavigation } from './navigation.js';
import { initializeBrackets } from './brackets.js';
import { setupTeamsSlider } from './teams.js';
import { addPageTransitions } from './animations.js';

// Initialize all components when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  // Setup navigation and mobile menu
  setupNavigation();
  
  // Initialize tournament countdown timers
  setupCountdown('featured-countdown', '2025-07-15T18:00:00');
  
  // Initialize tournament brackets
  initializeBrackets();
  
  // Setup teams slider
  setupTeamsSlider();
  
  // Add page transition animations
  addPageTransitions();
  
  // Initialize any other components
  initializeComponents();
});

// General initialization for miscellaneous components
function initializeComponents() {
  // Add hover effects to cards
  const cards = document.querySelectorAll('.tournament-card, .team-card, .news-card');
  cards.forEach(card => {
    card.addEventListener('mouseenter', () => {
      card.classList.add('card-hover');
    });
    
    card.addEventListener('mouseleave', () => {
      card.classList.remove('card-hover');
    });
  });
  
  // Add click listeners to buttons
  const buttons = document.querySelectorAll('.btn');
  buttons.forEach(button => {
    button.addEventListener('click', (e) => {
      // Add ripple effect
      const ripple = document.createElement('span');
      ripple.classList.add('btn-ripple');
      button.appendChild(ripple);
      
      const rect = button.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      ripple.style.left = `${x}px`;
      ripple.style.top = `${y}px`;
      
      setTimeout(() => {
        ripple.remove();
      }, 600);
    });
  });
  
  // Animate sections when they come into view
  const sections = document.querySelectorAll('.section');
  
  const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
  };
  
  const sectionObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-fadeIn');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);
  
  sections.forEach(section => {
    sectionObserver.observe(section);
  });
}