// Authentication functionality

/**
 * Initialize authentication forms and handlers
 */
document.addEventListener('DOMContentLoaded', () => {
  const signInForm = document.getElementById('signInForm');
  const registerForm = document.getElementById('registerForm');
  
  // Handle sign in form submission
  signInForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = signInForm.email.value;
    const password = signInForm.password.value;
    const remember = signInForm.remember?.checked;
    
    try {
      // Add loading state
      const submitButton = signInForm.querySelector('button[type="submit"]');
      submitButton.disabled = true;
      submitButton.innerHTML = 'Signing in...';
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Store auth state (temporary implementation)
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('user', JSON.stringify({ email }));
      
      // Redirect to home page
      window.location.href = '/';
    } catch (error) {
      console.error('Sign in failed:', error);
      alert('Sign in failed. Please try again.');
    } finally {
      if (submitButton) {
        submitButton.disabled = false;
        submitButton.innerHTML = 'Sign In';
      }
    }
  });
  
  // Handle registration form submission
  registerForm?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = registerForm.username.value;
    const email = registerForm.email.value;
    const password = registerForm.password.value;
    const confirmPassword = registerForm.confirmPassword.value;
    
    // Validate passwords match
    if (password !== confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    
    try {
      // Add loading state
      const submitButton = registerForm.querySelector('button[type="submit"]');
      submitButton.disabled = true;
      submitButton.innerHTML = 'Creating account...';
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Store auth state (temporary implementation)
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('user', JSON.stringify({ username, email }));
      
      // Redirect to home page
      window.location.href = '/';
    } catch (error) {
      console.error('Registration failed:', error);
      alert('Registration failed. Please try again.');
    } finally {
      if (submitButton) {
        submitButton.disabled = false;
        submitButton.innerHTML = 'Create Account';
      }
    }
  });
  
  // Check authentication state on page load
  const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  
  if (isAuthenticated && user) {
    // Update UI for authenticated user
    updateAuthUI(user);
  }
});

/**
 * Update UI elements based on authentication state
 */
function updateAuthUI(user) {
  const navButtons = document.querySelector('.nav-buttons');
  if (!navButtons) return;
  
  navButtons.innerHTML = `
    <div class="user-menu">
      <span class="user-email">${user.email}</span>
      <button class="btn btn-secondary" onclick="handleSignOut()">Sign Out</button>
    </div>
  `;
}

/**
 * Handle user sign out
 */
window.handleSignOut = () => {
  localStorage.removeItem('isAuthenticated');
  localStorage.removeItem('user');
  window.location.href = '/';
};