// Teams slider functionality

/**
 * Sets up the teams slider with proper interactions
 */
export function setupTeamsSlider() {
  const teamsSlider = document.getElementById('teams-slider');
  if (!teamsSlider) return;
  
  // Convert team cards data to a more dynamic format
  const teamCards = Array.from(teamsSlider.querySelectorAll('.team-card'));
  
  // Add hover effects and animations to team cards
  teamCards.forEach((card, index) => {
    // Add delay to stagger animations
    card.style.animationDelay = `${index * 0.1}s`;
    
    // Add parallax effect to team logo on mouse move
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left; // x position within the element
      const y = e.clientY - rect.top; // y position within the element
      
      // Calculate percentage
      const xPercent = (x / rect.width - 0.5) * 2; // -1 to 1
      const yPercent = (y / rect.height - 0.5) * 2; // -1 to 1
      
      // Apply transform to logo
      const logo = card.querySelector('.team-logo');
      if (logo) {
        logo.style.transform = `translate(${xPercent * 5}px, ${yPercent * 5}px)`;
      }
      
      // Apply subtle transform to card
      card.style.transform = `translateY(-7px) perspective(1000px) rotateX(${yPercent * 2}deg) rotateY(${xPercent * 2}deg)`;
    });
    
    // Reset transforms when mouse leaves
    card.addEventListener('mouseleave', () => {
      const logo = card.querySelector('.team-logo');
      if (logo) {
        logo.style.transform = '';
      }
      card.style.transform = '';
    });
  });
  
  // If we're on mobile, make the slider scrollable with touch
  if (window.innerWidth <= 768) {
    let isDown = false;
    let startX;
    let scrollLeft;
    
    teamsSlider.addEventListener('mousedown', (e) => {
      isDown = true;
      teamsSlider.classList.add('active');
      startX = e.pageX - teamsSlider.offsetLeft;
      scrollLeft = teamsSlider.scrollLeft;
    });
    
    teamsSlider.addEventListener('mouseleave', () => {
      isDown = false;
      teamsSlider.classList.remove('active');
    });
    
    teamsSlider.addEventListener('mouseup', () => {
      isDown = false;
      teamsSlider.classList.remove('active');
    });
    
    teamsSlider.addEventListener('mousemove', (e) => {
      if (!isDown) return;
      e.preventDefault();
      const x = e.pageX - teamsSlider.offsetLeft;
      const walk = (x - startX) * 2;
      teamsSlider.scrollLeft = scrollLeft - walk;
    });
    
    // Add visual indicator for scrolling
    const scrollIndicator = document.createElement('div');
    scrollIndicator.classList.add('scroll-indicator');
    scrollIndicator.innerHTML = '<span>←</span><span>Scroll</span><span>→</span>';
    
    const teamsSection = document.querySelector('.top-teams');
    if (teamsSection) {
      teamsSection.appendChild(scrollIndicator);
    }
    
    // Hide indicator after 3 seconds
    setTimeout(() => {
      scrollIndicator.classList.add('fade-out');
      setTimeout(() => {
        scrollIndicator.remove();
      }, 1000);
    }, 3000);
    
    // Add scroll indicator styles
    const style = document.createElement('style');
    style.textContent = `
      .scroll-indicator {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        margin-top: 15px;
        color: var(--color-text-muted);
        font-size: 0.8rem;
        animation: pulse 2s infinite ease-in-out;
        opacity: 1;
        transition: opacity 1s ease;
      }
      
      .scroll-indicator.fade-out {
        opacity: 0;
      }
    `;
    document.head.appendChild(style);
  }
}