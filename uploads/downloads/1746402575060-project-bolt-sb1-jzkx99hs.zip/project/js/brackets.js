// Tournament brackets visualization

/**
 * Initializes the tournament brackets visualization
 */
export function initializeBrackets() {
  const bracketContainer = document.getElementById('bracket-container');
  const bracketButtons = document.querySelectorAll('.bracket-btn');
  
  if (!bracketContainer) return;
  
  // Tournament data for different games
  const tournaments = {
    valorant: {
      name: 'Valorant Masters',
      rounds: 3,
      teams: [
        { name: 'Neon Vipers', seed: 1 },
        { name: 'Phantom Squad', seed: 8 },
        { name: 'Solar Flare', seed: 4 },
        { name: 'Cosmic Drift', seed: 5 },
        { name: 'Dragon Reapers', seed: 2 },
        { name: 'Toxic Shadows', seed: 7 },
        { name: 'Night Stalkers', seed: 3 },
        { name: 'Venom Pulse', seed: 6 }
      ]
    },
    csgo: {
      name: 'CS:GO Championship',
      rounds: 3,
      teams: [
        { name: 'Phoenix Force', seed: 1 },
        { name: 'Shadow Ops', seed: 8 },
        { name: 'Stealth Tactics', seed: 4 },
        { name: 'Vertex Gaming', seed: 5 },
        { name: 'Elite Snipers', seed: 2 },
        { name: 'Phantom Squad', seed: 7 },
        { name: 'Omega Team', seed: 3 },
        { name: 'Neon Vipers', seed: 6 }
      ]
    },
    apex: {
      name: 'Apex Legends Cup',
      rounds: 3,
      teams: [
        { name: 'Apex Predators', seed: 1 },
        { name: 'Zone Runners', seed: 8 },
        { name: 'Storm Chasers', seed: 4 },
        { name: 'Neon Vipers', seed: 5 },
        { name: 'Loot Lords', seed: 2 },
        { name: 'Diamond Squad', seed: 7 },
        { name: 'Phantom Squad', seed: 3 },
        { name: 'Death Squad', seed: 6 }
      ]
    }
  };
  
  // Set initial tournament
  let currentTournament = 'valorant';
  
  // Create bracket visualization for the selected tournament
  function renderBracket(tournamentKey) {
    const tournament = tournaments[tournamentKey];
    
    if (!tournament) return;
    
    // Clear previous bracket
    bracketContainer.innerHTML = '';
    
    // Create the bracket wrapper
    const bracketWrapper = document.createElement('div');
    bracketWrapper.className = 'bracket-wrapper';
    
    // Add tournament title
    const tournamentTitle = document.createElement('h3');
    tournamentTitle.className = 'bracket-title';
    tournamentTitle.textContent = tournament.name;
    bracketWrapper.appendChild(tournamentTitle);
    
    // Create the bracket structure
    const bracketStructure = document.createElement('div');
    bracketStructure.className = 'bracket-structure';
    
    // Calculate number of teams and matches
    const numTeams = tournament.teams.length;
    const numRounds = tournament.rounds;
    
    // Create rounds
    for (let round = 0; round < numRounds; round++) {
      const roundColumn = document.createElement('div');
      roundColumn.className = 'bracket-round';
      
      // Set round title
      const roundTitle = document.createElement('div');
      roundTitle.className = 'round-title';
      
      switch (round) {
        case 0:
          roundTitle.textContent = 'Quarterfinals';
          break;
        case 1:
          roundTitle.textContent = 'Semifinals';
          break;
        case 2:
          roundTitle.textContent = 'Finals';
          break;
        default:
          roundTitle.textContent = `Round ${round + 1}`;
      }
      
      roundColumn.appendChild(roundTitle);
      
      // Calculate matches for this round
      const matchesInRound = numTeams / Math.pow(2, round + 1);
      
      // Create matches
      for (let match = 0; match < matchesInRound; match++) {
        const matchContainer = document.createElement('div');
        matchContainer.className = 'bracket-match';
        
        // For first round, use actual teams
        if (round === 0) {
          const team1Index = match * 2;
          const team2Index = match * 2 + 1;
          
          const team1 = tournament.teams[team1Index];
          const team2 = tournament.teams[team2Index];
          
          // Create team elements
          const team1Element = createTeamElement(team1.name, team1.seed);
          const team2Element = createTeamElement(team2.name, team2.seed);
          
          // Add dummy score (random winner for visualization)
          const randomWinner = Math.random() > 0.5 ? 0 : 1;
          if (randomWinner === 0) {
            team1Element.classList.add('winner');
          } else {
            team2Element.classList.add('winner');
          }
          
          matchContainer.appendChild(team1Element);
          matchContainer.appendChild(team2Element);
        } else {
          // For later rounds, create placeholder teams
          const placeholder1 = createTeamElement('TBD', '');
          const placeholder2 = createTeamElement('TBD', '');
          
          // For semifinals, determine winners from quarterfinals
          if (round === 1) {
            // Just for visualization, set some teams as winners
            if (match === 0) {
              placeholder1.textContent = tournament.teams[0].name;
              placeholder1.classList.add('winner');
            } else {
              placeholder1.textContent = tournament.teams[4].name;
              placeholder1.classList.add('winner');
            }
          }
          
          // For finals, set a winner
          if (round === 2) {
            placeholder1.textContent = tournament.teams[0].name;
            placeholder1.classList.add('winner');
          }
          
          matchContainer.appendChild(placeholder1);
          matchContainer.appendChild(placeholder2);
        }
        
        roundColumn.appendChild(matchContainer);
      }
      
      bracketStructure.appendChild(roundColumn);
    }
    
    bracketWrapper.appendChild(bracketStructure);
    bracketContainer.appendChild(bracketWrapper);
  }
  
  // Helper function to create a team element
  function createTeamElement(name, seed) {
    const teamElement = document.createElement('div');
    teamElement.className = 'bracket-team';
    
    if (seed) {
      const seedElement = document.createElement('span');
      seedElement.className = 'team-seed';
      seedElement.textContent = seed;
      teamElement.appendChild(seedElement);
    }
    
    const nameElement = document.createElement('span');
    nameElement.className = 'team-name';
    nameElement.textContent = name;
    teamElement.appendChild(nameElement);
    
    // Add score element
    if (name !== 'TBD') {
      const scoreElement = document.createElement('span');
      scoreElement.className = 'team-score';
      scoreElement.textContent = Math.floor(Math.random() * 3);
      teamElement.appendChild(scoreElement);
    }
    
    return teamElement;
  }
  
  // Add event listeners to tournament selector buttons
  bracketButtons.forEach(button => {
    button.addEventListener('click', () => {
      // Remove active class from all buttons
      bracketButtons.forEach(btn => btn.classList.remove('active'));
      
      // Add active class to clicked button
      button.classList.add('active');
      
      // Get tournament key from data attribute
      const tournamentKey = button.dataset.tournament;
      
      // Render the bracket
      renderBracket(tournamentKey);
      
      // Update current tournament
      currentTournament = tournamentKey;
    });
  });
  
  // Add CSS for bracket visualization
  addBracketStyles();
  
  // Initial render
  renderBracket(currentTournament);
}

// Add styles for bracket visualization
function addBracketStyles() {
  const style = document.createElement('style');
  style.textContent = `
    .bracket-wrapper {
      width: 100%;
      overflow-x: auto;
      padding-bottom: 20px;
    }
    
    .bracket-title {
      text-align: center;
      margin-bottom: 20px;
      color: var(--color-accent-blue);
      font-family: var(--font-primary);
      font-size: 1.5rem;
    }
    
    .bracket-structure {
      display: flex;
      justify-content: space-between;
      min-width: 700px;
    }
    
    .bracket-round {
      display: flex;
      flex-direction: column;
      flex: 1;
      position: relative;
    }
    
    .round-title {
      text-align: center;
      margin-bottom: 20px;
      font-family: var(--font-primary);
      font-size: 1rem;
      color: var(--color-text-muted);
      text-transform: uppercase;
    }
    
    .bracket-match {
      display: flex;
      flex-direction: column;
      margin: 10px;
      border: 1px solid var(--color-card-border);
      border-radius: var(--border-radius-sm);
      overflow: hidden;
      background-color: var(--color-card-bg);
      position: relative;
      height: 80px;
    }
    
    .bracket-team {
      display: flex;
      align-items: center;
      padding: 10px;
      height: 40px;
      position: relative;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    }
    
    .bracket-team:last-child {
      border-bottom: none;
    }
    
    .bracket-team.winner {
      background-color: rgba(0, 240, 255, 0.1);
    }
    
    .team-seed {
      width: 20px;
      height: 20px;
      border-radius: 50%;
      background-color: rgba(255, 255, 255, 0.1);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.7rem;
      margin-right: 10px;
      font-weight: 600;
    }
    
    .team-name {
      flex: 1;
      font-size: 0.9rem;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    
    .team-score {
      font-family: var(--font-primary);
      font-weight: 700;
      font-size: 1rem;
      color: var(--color-text);
      margin-left: 10px;
    }
    
    .winner .team-score {
      color: var(--color-accent-blue);
    }
    
    @media (max-width: 768px) {
      .bracket-structure {
        min-width: 500px;
      }
      
      .bracket-team {
        padding: 5px 10px;
        height: 35px;
      }
      
      .bracket-match {
        height: 70px;
        margin: 5px;
      }
    }
  `;
  
  document.head.appendChild(style);
}