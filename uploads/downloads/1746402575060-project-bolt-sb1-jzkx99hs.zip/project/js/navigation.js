// Navigation functionality

/**
 * Sets up the navigation bar behavior and mobile menu
 */
export function setupNavigation() {
  // Elements
  const header = document.querySelector('.main-header');
  const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
  const mainNav = document.querySelector('.main-nav');
  const body = document.body;
  
  // Create menu overlay if it doesn't exist
  let menuOverlay = document.querySelector('.menu-overlay');
  if (!menuOverlay) {
    menuOverlay = document.createElement('div');
    menuOverlay.classList.add('menu-overlay');
    body.appendChild(menuOverlay);
  }
  
  // Toggle mobile menu
  mobileMenuToggle?.addEventListener('click', () => {
    mobileMenuToggle.classList.toggle('active');
    mainNav?.classList.toggle('active');
    menuOverlay.classList.toggle('active');
    body.classList.toggle('menu-open');
  });
  
  // Close mobile menu when clicking overlay
  menuOverlay.addEventListener('click', () => {
    mobileMenuToggle?.classList.remove('active');
    mainNav?.classList.remove('active');
    menuOverlay.classList.remove('active');
    body.classList.remove('menu-open');
  });
  
  // Close mobile menu when clicking a nav link
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      mobileMenuToggle?.classList.remove('active');
      mainNav?.classList.remove('active');
      menuOverlay.classList.remove('active');
      body.classList.remove('menu-open');
    });
  });
  
  // Handle header scroll effect
  let lastScrollTop = 0;
  
  window.addEventListener('scroll', () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    // Add or remove scrolled class to change header appearance
    if (scrollTop > 50) {
      header?.classList.add('header-scrolled');
    } else {
      header?.classList.remove('header-scrolled');
    }
    
    // Hide/show header based on scroll direction
    if (scrollTop > lastScrollTop && scrollTop > 200) {
      // Scrolling down
      header?.classList.add('header-hidden');
    } else {
      // Scrolling up
      header?.classList.remove('header-hidden');
    }
    
    lastScrollTop = scrollTop;
  });
  
  // Smooth scroll for navigation links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      
      const targetElement = document.querySelector(targetId);
      if (!targetElement) return;
      
      const headerHeight = header?.offsetHeight || 0;
      const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
      
      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
    });
  });
  
  // Add active class to current section in navigation
  function highlightActiveNavLink() {
    const sections = document.querySelectorAll('.section');
    const navLinks = document.querySelectorAll('.nav-link');
    
    let current = '';
    
    sections.forEach(section => {
      const sectionTop = section.offsetTop;
      const sectionHeight = section.offsetHeight;
      const headerHeight = header?.offsetHeight || 0;
      
      if (window.pageYOffset >= sectionTop - headerHeight - 100) {
        current = section.getAttribute('id');
      }
    });
    
    navLinks.forEach(link => {
      link.classList.remove('nav-active');
      const href = link.getAttribute('href');
      if (href === `#${current}`) {
        link.classList.add('nav-active');
      }
    });
  }
  
  window.addEventListener('scroll', highlightActiveNavLink);
  
  // Initial call to set active link
  highlightActiveNavLink();
}