// Page transitions and animations

/**
 * Add page transitions and animations to the website
 */
export function addPageTransitions() {
  // Add fade-in animation to sections when they come into view
  const sections = document.querySelectorAll('.section');
  
  // Only run if IntersectionObserver is available
  if ('IntersectionObserver' in window) {
    const observerOptions = {
      root: null,
      rootMargin: '0px',
      threshold: 0.1
    };
    
    const sectionObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('page-visible');
          
          // Animate children with staggered delay
          const children = entry.target.querySelectorAll('.tournament-card, .team-card, .news-card, .cta-content');
          children.forEach((child, index) => {
            setTimeout(() => {
              child.classList.add('element-visible');
            }, 100 * index);
          });
          
          // Stop observing after animation
          sectionObserver.unobserve(entry.target);
        }
      });
    }, observerOptions);
    
    sections.forEach(section => {
      section.classList.add('page-transition');
      sectionObserver.observe(section);
    });
  } else {
    // Fallback for browsers that don't support IntersectionObserver
    sections.forEach(section => {
      section.classList.add('page-visible');
    });
  }
  
  // Add page transition CSS
  const style = document.createElement('style');
  style.textContent = `
    .page-transition {
      opacity: 0;
      transform: translateY(30px);
      transition: opacity 0.6s ease, transform 0.6s ease;
    }
    
    .page-visible {
      opacity: 1;
      transform: translateY(0);
    }
    
    .tournament-card, .team-card, .news-card, .cta-content {
      opacity: 0;
      transform: translateY(20px);
      transition: opacity 0.4s ease, transform 0.4s ease;
    }
    
    .element-visible {
      opacity: 1;
      transform: translateY(0);
    }
    
    /* Hero animation */
    .hero-content {
      animation: fadeIn 1s ease-out forwards;
    }
    
    @keyframes heroBackgroundAnimation {
      0% {
        background-position: 0% 50%;
      }
      50% {
        background-position: 100% 50%;
      }
      100% {
        background-position: 0% 50%;
      }
    }
    
    /* Button hover animations */
    .btn::before {
      content: '';
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.1), transparent);
      transform: translateX(-100%);
      transition: transform 0.6s;
    }
    
    .btn:hover::before {
      transform: translateX(100%);
    }
    
    /* Ripple effect for buttons */
    .btn-ripple {
      position: absolute;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.3);
      transform: scale(0);
      animation: ripple 0.6s linear;
      pointer-events: none;
    }
    
    @keyframes ripple {
      to {
        transform: scale(4);
        opacity: 0;
      }
    }
    
    /* Pulse animation for countdown */
    .pulse-animation {
      animation: pulseText 0.5s ease-out;
    }
    
    @keyframes pulseText {
      0% {
        transform: scale(1);
      }
      50% {
        transform: scale(1.2);
        color: var(--color-accent-red);
      }
      100% {
        transform: scale(1);
      }
    }
  `;
  
  document.head.appendChild(style);
  
  // Add preloader animation
  const preloader = document.createElement('div');
  preloader.className = 'preloader';
  preloader.innerHTML = `
    <div class="preloader-content">
      <div class="preloader-logo">NEXUS<span class="accent-text">ARENA</span></div>
      <div class="preloader-spinner"></div>
    </div>
  `;
  
  document.body.appendChild(preloader);
  
  // Add preloader styles
  const preloaderStyle = document.createElement('style');
  preloaderStyle.textContent = `
    .preloader {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: var(--color-background);
      z-index: 9999;
      display: flex;
      align-items: center;
      justify-content: center;
      opacity: 1;
      transition: opacity 0.6s ease, visibility 0.6s ease;
    }
    
    .preloader-content {
      text-align: center;
    }
    
    .preloader-logo {
      font-family: var(--font-primary);
      font-weight: 900;
      font-size: 2.5rem;
      margin-bottom: 20px;
      animation: textShadowPulse 6s infinite linear;
    }
    
    .preloader-spinner {
      width: 50px;
      height: 50px;
      border: 3px solid transparent;
      border-top-color: var(--color-accent-blue);
      border-radius: 50%;
      animation: spin 1s infinite linear;
      margin: 0 auto;
    }
    
    .preloader-hidden {
      opacity: 0;
      visibility: hidden;
    }
    
    @keyframes spin {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }
  `;
  
  document.head.appendChild(preloaderStyle);
  
  // Hide preloader when page is loaded
  window.addEventListener('load', () => {
    setTimeout(() => {
      preloader.classList.add('preloader-hidden');
      
      // Remove preloader from DOM after animation
      setTimeout(() => {
        preloader.remove();
      }, 600);
    }, 800);
  });
  
  // If page is already loaded, hide preloader immediately
  if (document.readyState === 'complete') {
    setTimeout(() => {
      preloader.classList.add('preloader-hidden');
      
      setTimeout(() => {
        preloader.remove();
      }, 600);
    }, 800);
  }
}